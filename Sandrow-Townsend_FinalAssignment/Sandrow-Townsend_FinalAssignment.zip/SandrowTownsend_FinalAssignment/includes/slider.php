		<div id="sidr">
		  <ul>
		    <li><a href="index.php">home</a></li>
		    <li><a href="about.php">about us</a></li>
		    <li><a href="#">services</a></li>
		    <li><a href="#">portfolio</a></li>
		    <li><a href="contact.php">contact us</a></li>
		  </ul>
		</div>