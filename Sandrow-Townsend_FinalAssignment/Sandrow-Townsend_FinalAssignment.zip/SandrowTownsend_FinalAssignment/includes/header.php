<!DOCTYPE html>
<html lang="en">
	<head>
		<title>UI Brush</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="styles/normalize.css" type="text/css">
		<link rel="stylesheet" href="styles/main.css" type="text/css">
		<link rel="stylesheet" href="styles/fonts.css" type="text/css">
		<link rel="stylesheet" href="styles/font-awesome.css">
		<link rel="stylesheet" href="javascript/stylesheets/jquery.sidr.dark.css">
		<script src="script/main.js"></script>
		<script src="javascript/jquery-1.9.1.min.js"></script>
		<script src="javascript/modernizr.js"></script>
		<script src="javascript/javascript.js"></script>
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">

	</head>

