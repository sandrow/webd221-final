<?php include "includes/header.php"; ?>

	<body>

		<header>
			<nav>
				<div class="container clearfix">

					<h1><span class="orange_color ">UI</span>Brush</h1>
					<span><a id="simple-menu" href="#sidr"><i id="hit" class="fa fa-bars stack-nav"></i></a></span>
					<ul>
						<li><a href="index.php">HOME</a></li>	
						<li><a href="about.php">ABOUT US</a></li>	
						<li><a href="#">SERVICES</a></li>
						<li><a href="#">PORTFOLIO</a></li>
						<li><a class="custom_line" href="contact.php">CONTACT US</a></li>				
					</ul>
				</div>
			</nav>
		</header>
<?php include "includes/slider.php"; ?>

		<section id="about_us">
			<article class="hero_section ">
				<div class="container center">
					<h6>Talk <span class="orange_color">To Us</span></h6>
					<p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio<br> nihil impedit quo facilis est et expedita distinctio minus id quod maxime placeat facere possimus, omnis voluptas assumenda est.</p>
				</div>
			</article>
			<article>
				<div class="container center">
					<h2><span class="orange_line">Contact Us</span></h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
				</div>
			</article>
			<aside class=" container">
				<div class=" clearfix map">
					<img src="images/map.jpg" alt="">
				</div>
				<div class=" clearfix">
					<h4>Contact Details:</h4>
					<p class="form"><i class="fa fa-phone"></i>(+91) 0975 720 3582</p><br>
					<p class="form"><i class="fa fa-envelope-o"></i>Email@domain.com</p><br>
					<p class="form"><i class="fa fa-map-marker"></i>No.235, New St, 25th Sector, <br>London, England</p><br>
					<input class="name" type="text" value="Name">
					<input class="email" type="text" value="Email">
					<input class="message" type="text" value="Message">
					<input class="button" type="button" value="Submit"></input>
				</div>
			</aside>
		</section>

<?php include "includes/footer.php"; ?>
