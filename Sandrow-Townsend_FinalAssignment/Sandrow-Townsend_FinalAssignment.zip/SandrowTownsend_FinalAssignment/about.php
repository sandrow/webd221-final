<?php include "includes/header.php"; ?>

	<body>

		<header>
			<nav>
				<div class="container clearfix">
					<h1><span class="orange_color ">UI</span>Brush</h1>
					<span><a id="simple-menu" href="#sidr"><i id="hit" class="fa fa-bars stack-nav"></i></a></span>
					<ul>
						<li><a href="index.php">HOME</a></li>	
						<li><a class="custom_line" href="about.php">ABOUT US</a></li>	
						<li><a href="#">SERVICES</a></li>
						<li><a href="#">PORTFOLIO</a></li>
						<li><a href="contact.php">CONTACT US</a></li>				
					</ul>
				</div>
			</nav>
		</header>
<?php include "includes/slider.php"; ?>

		<section id="about_us">
			<article class="hero_section ">
				<div class="container center">
					<h6>Who <span class="orange_color">We Are</span></h6>
					<p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio<br> nihil impedit quo facilis est et expedita distinctio minus id quod maxime placeat facere possimus, omnis voluptas assumenda est.</p>
				</div>
			</article>
			<article>
				<div class="container center">
					<h2><span class="orange_line">About Us</span></h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
				</div>
			</article>
		</section>

		<section id="company">
			<article>
				<div class="container center clearfix">
					<h2><span class="orange_line">Our Team</span></h2>
					<aside class="group">
					<ul>
						<li>
							<div>
								<img src="images/squad_2.png" alt="">
								<h5>Tina</h5>
								<p class="position">Finacial Manager</p>
								<p class="blurb">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
							</div>
						</li>
						<li>
							<div>
								<img src="images/squad_1.png" alt="">
								<h5>Neil</h5>
								<p class="position">Project manager</p>
								<p class="blurb">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
							</div>
						</li>
						<li>
							<div>
								<img src="images/squad_3.png" alt="">
								<h5>Elzey</h5>
								<p class="position">Marketing Executive</p>
								<p class="blurb">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
							</div>
						</li>
						<li>
							<div>
								<img src="images/squad_4.png" alt="">
								<h5>Maes</h5>
								<p class="position">CEO</p>
								<p class="blurb">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
							</div>
						</li>
					</ul>
					</aside>
				</div>
			</article>
		</section>

		<section id="statment" class="container">
			<article>
				<div class="left_side">
					<h2><span class="orange_line">Our Mission</span></h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p>
				</div>
				<div class="right_side">
					<img src="images/objective.jpg" alt="">
				</div>
			</article>
		</section>

		<?php include "includes/footer.php"; ?>
