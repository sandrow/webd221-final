<?php include "includes/header.php"; ?>

	<body>

		<header>
			<nav>
				<div class="container clearfix">
					<h1><span class="orange_color ">UI</span>Brush</h1>
					<span><a id="simple-menu" href="#sidr"><i id="hit" class="fa fa-bars stack-nav"></i></a></span>
					<ul>
						<li ><a class="custom_line" href="index.php">HOME</a></li>	
						<li><a href="about.php">ABOUT US</a></li>	
						<li><a href="#">SERVICES</a></li>
						<li><a href="#">PORTFOLIO</a></li>
						<li><a href="contact.php">CONTACT US</a></li>				
					</ul>
				</div>
			</nav>
		</header>
<?php include "includes/slider.php"; ?>

		<section id="main_slider">
			<div class="hero_section ">
				<div class="head_contain">
					<h2>Welcome To UIBrush</h2> 
					<h3>We Provide Ultimate Free PSD Templates</h3>
					<i class="fa fa-angle-left"></i>
					<i class="fa fa-angle-right"></i>
				</div>
				
			</div>
			
			<div class="orange_bottom center">
				<h3>Lorem ipsum dolor sit amet <span class="span_underline">consectetuer adipiscing elit</span></h3>
			</div>
		</section>

		<section id="content">
			<div class="container">
				<div class="center">
					<h2><span class="orange_line">UIBrush</span></h2>

					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in 
					voluptate velit esse cillum.</p>
				</div>

				<div>
					<div class="four_sections">
						<div class="center">
							<i class="fa fa-th-list"></i>
							<h4>Innovative Design</h4>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua. </p>
					</div>

					<div class="four_sections">
						<div class="center">
							<i class="fa fa-code"></i>
							<h4>Clean Coding</h4>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua. </p>
					</div>

					<div class="four_sections">
						<div class="center">
							<i class="fa fa-location-arrow"></i>
							<h4>Quick Delivery</h4>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua. </p>
					</div>

					<div class="four_sections">
						<div class="center">
							<i class="fa fa-phone"></i>
							<h4>Best Support</h4>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua. </p>
					</div>
				</div>
			</div>
		</section>

		<section id="projects">

			<div class="container">
				<article class="heading_two center">
					<h2><span class="orange_line">Recent Projects</span></h2>

					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua.</p>
				</article>

				
				<ul class="portfolio_samples  clearfix">
					<li>
						<div class="sample">
							<img src="images/portfolio_1.jpg" alt="">
							<div >
								<h5>Portfolio One</h5>
								<div class="greyLine "></div>
								<p>Lorem ipsum dolor sit amet.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="sample">
							<img src="images/portfolio_2.jpg" alt="">
							<div>
								<h5>Portfolio Two</h5>
								<div class="greyLine "></div>
								<p>Lorem ipsum dolor sit amet.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="sample">
							<img src="images/portfolio_3.jpg" alt="">
							<div>
								<h5>Portfolio Three</h5>
								<div class="greyLine "></div>
								<p>Lorem ipsum dolor sit amet.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="sample">
							<img src="images/portfolio_4.jpg" alt="">
							<div>
								<h5>Portfolio Four</h5>
								<div class="greyLine "></div>
								<p>Lorem ipsum dolor sit amet.</p>
							</div>
						</div>
					</li>
					
				</ul>
			</div>

		</section>

<?php include "includes/footer.php"; ?>
		


